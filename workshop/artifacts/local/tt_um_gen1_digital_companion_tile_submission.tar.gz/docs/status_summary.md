# Status summary

## Verified

- P65 RTL exists in `hardware/rtl/tt_um_gen1_digital_companion_tile.v`.
- This package mirrors that RTL in `src/project.v`.
- Existing Picasso P65 result reports Verilator lint pass.
- Existing Picasso P65 result reports Verilator simulation pass.
- Existing Picasso P65 result reports Yosys synthesis pass.
- Existing Picasso P65 result reports 158 generic Yosys cells.
- Smoke scenarios cover up verify, down verify and timeout fault.
- Existing smoke result reports 0 raw payload outputs observed.
- Packaged RTL reports Verilator lint pass on Picasso.
- Packaged RTL reports Verilator binary simulation pass on Picasso when launched with `module load pytorch/2.10.0`.
- Packaged RTL reports Yosys synthesis pass on Picasso with 158 generic cells.
- Packaged RTL passes the Yosys SAT contract checks for up verify, down verify, timeout and clear.

## Provisional

- This package has not yet run the official Tiny Tapeout GDS and Docs GitHub Actions.
- The final shuttle/process template should be confirmed during the workshop.
- Clock documentation uses a conservative 20 MHz placeholder until official flow/timing guidance.
- `uio_oe = 8'hff` should be confirmed against the exact workshop template and board expectations.
- A previous Picasso package job failed Verilator binary simulation because it did not load the `pytorch/2.10.0` environment. The corrected job passes.

## Do not claim

- Do not claim real memristive devices.
- Do not claim analog 1T1R behavior.
- Do not claim physical privacy.
- Do not claim measured energy.
- Do not claim full local AI or LLM inference.
- Do not claim tapeout readiness until the official GDS and Docs actions pass.

## Next actions before June 22

1. Create a GitHub repository from the official Tiny Tapeout Verilog template.
2. Copy this package into that repository.
3. Run the official test, GDS and Docs actions.
4. Fix only template, documentation or warning issues unless Matt recommends an architectural change.
5. Submit the project once actions are green.
