# Sources used

Official Tiny Tapeout sources checked on 2026-05-31:

- Tiny Tapeout home: https://tinytapeout.com/
- FAQ: https://www.tinytapeout.com/faq/
- Advanced workshop submission guide: https://tinytapeout.com/guides/advanced-workshop/submit-your-design/
- Working with HDLs: https://www.tinytapeout.com/hdl/
- HDL testing guide: https://www.tinytapeout.com/hdl/testing/
- Clock specification: https://www.tinytapeout.com/specs/clock/
- Memory specification: https://www.tinytapeout.com/specs/memory/
- TT06 previous submissions: https://tinytapeout.com/chips/tt06/

Previous submissions used as framing examples:

- TT06 Neurocore: https://tinytapeout.com/chips/tt06/tt_um_neurocore/
- TT06 SiliconJackets systolic array: https://tinytapeout.com/chips/tt06/tt_um_SJ/

Local project evidence:

- `artifacts/picasso/gen1_p65_tiny_tapeout_digital_companion/results.json`
- `docs/hardware/tiny_tapeout_workshop_playbook.md`
- `docs/hardware/tiny_tapeout_unified_digital_companion_framework.md`

